// Inject Ember AS into the web page window object
const script = document.createElement('script');
script.textContent = `
  window.ember = {
    isEmberAS: true,
    version: '1.0.0',
    connect: async () => {
      console.log('Ember AS Web3 Provider Connected');
      return window.postMessage({ type: 'EMBER_CONNECT_REQUEST' }, '*');
    }
  };
`;
(document.head || document.documentElement).appendChild(script);
script.remove();
