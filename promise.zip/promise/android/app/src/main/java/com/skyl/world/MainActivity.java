package com.skyl.world;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
